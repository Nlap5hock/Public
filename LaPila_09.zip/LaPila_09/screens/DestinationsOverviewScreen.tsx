import React, { useLayoutEffect } from "react";
import { View, Text, StyleSheet, FlatList, ListRenderItem } from "react-native";
import { RouteProp } from "@react-navigation/native";
import { RouteProp } from "@react-navigation/native";

import { COUNTRIES, DESTINATIONS } from "../data/dummy-data";
import DestinationItem from "../components/DestinationItem";

// Define types
type RootStackParamList = {
  DestinationsOverviewScreen: { countryId: string };
};

type Destination = {
  id: string;
  countryId: string;
  name: string;
  imageUrl: string;
  costVisit: string;
  foundedYear: number;
  rating: number;
  description: string;
  index: number;
};

type DestinationsOverviewScreenProps = {
  navigation: StackNavigationProp<RootStackParamList, 'DestinationsOverviewScreen'>;
  route: RouteProp<RootStackParamList, 'DestinationsOverviewScreen'>;
};

function DestinationsOverviewScreen({ navigation, route }: DestinationsOverviewScreenProps) {
  const { countryId } = route.params;

  useLayoutEffect(() => {
    const country = COUNTRIES.find((country) => country.id === countryId);
    navigation.setOptions({ title: country ? country.name : undefined });
  }, [countryId, navigation]);

  const displayedDestinations = DESTINATIONS.filter(
    (destinationItem) => destinationItem.countryId === countryId
  );

  const renderDestinationItem: ListRenderItem<Destination> = ({ item }) => {
    const destinationItemProps = {
      name: item.name,
      imageUrl: item.imageUrl,
      costVisit: item.costVisit,
      foundedYear: item.foundedYear,
      rating: item.rating,
      description: item.description,
      listindex: item.index,
    };

    return <DestinationItem {...destinationItemProps} />;
  };

  return (
    <View style={styles.container}>
      <FlatList
        data={displayedDestinations}
        keyExtractor={(item) => item.id}
        renderItem={renderDestinationItem}
      />
    </View>
  );
}

export default DestinationsOverviewScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
});
