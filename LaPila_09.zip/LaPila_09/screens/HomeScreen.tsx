import React from "react";
import { View, Text, FlatList, ListRenderItem } from "react-native";
import { StackNavigationProp } from '@react-navigation/stack';
import { COUNTRIES } from "../data/dummy-data";
import CountryGridTitle from "../components/CountryGridTitle";

// Define types
type Country = {
  id: string;
  name: string;
  color: string;
};

type RootStackParamList = {
  DestinationsOverviewScreen: { countryId: string };
};

type HomeScreenProps = {
  navigation: StackNavigationProp<RootStackParamList, 'DestinationsOverviewScreen'>;
};

function HomeScreen({ navigation }: HomeScreenProps) {
  const renderCountryItem: ListRenderItem<Country> = ({ item }) => {
    function pressHandler() {
      navigation.navigate("DestinationsOverviewScreen", {
        countryId: item.id,
      });
    }

    return (
      <CountryGridTitle
        name={item.name}
        color={item.color}
        onPress={pressHandler}
      />
    );
  };

  return (
    <View>
      <FlatList
        data={COUNTRIES}
        keyExtractor={(item) => item.id}
        renderItem={renderCountryItem}
        numColumns={2}
      />
    </View>
  );
}

export default HomeScreen;
