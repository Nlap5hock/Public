class Destination {
  id: string;
  countryId: string;
  name: string;
  costVisit: string;
  foundedYear: number;
  rating: number;
  description: string;
  imageUrl: string;

  // Constructor function to initialize Destination instances
  constructor(
    id: string,
    countryId: string,
    name: string,
    costVisit: string,
    foundedYear: number,
    rating: number,
    description: string,
    imageUrl: string
  ) {
    this.id = id;
    this.countryId = countryId;
    this.name = name;
    this.costVisit = costVisit;
    this.foundedYear = foundedYear;
    this.rating = rating;
    this.description = description;
    this.imageUrl = imageUrl;
  }

  // Method to create a string representation of the destination
  toString(): string {
    return `${this.name} was founded in ${this.foundedYear} - Average Day Cost to Visit: $ ${this.costVisit}, Average Rating: ${this.rating} Description:  ${this.description}`;
  }
}

// Exporting the Destination class as the default export
export default Destination;
