const Colors = {
    trim300: "#rgb(26, 224, 205)",
    trim300o75: "#rgba(92, 40, 109, 0.75)",
    trim500: "#rgb(212, 201, 190)",
    trim800: "#rgb(114, 151, 143)",
    color300: "rgb(26, 174, 194)",
    color500: "#rgb(198, 133, 54)",
    color800: "#rgba(41, 7, 85, 0.67)",
};
// Exporting the component as the default export
export default Colors;