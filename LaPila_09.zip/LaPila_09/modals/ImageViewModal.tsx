import React from "react";
import { Modal, View, Button, Image, StyleSheet, Text } from "react-native";

type ImageViewModalProps = {
  isVisible: boolean;
  imageUrl: string;
  description: string;
  onClose: () => void;
};

// Functional component for displaying an image with description in a modal
function ImageViewModal({ isVisible, imageUrl, description, onClose }: ImageViewModalProps) {
  return (
    <View style={styles.container}>
      <Modal
        visible={isVisible}
        animationType="slide"
        transparent={false}
      >
        <View style={styles.modalContainer}>
          <Image style={styles.image} source={{ uri: imageUrl }} />
          <View style={styles.descriptionContainer}>
            <Text style={styles.description}>{description}</Text>
          </View>
          <Button title="Return to Countries" onPress={onClose} />
        </View>
      </Modal>
    </View>
  );
}

export default ImageViewModal;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  modalContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#7a4f80",
  },
  image: {
    width: "90%",
    height: "50%",
    resizeMode: "contain",
  },
  descriptionContainer: {
    flex: 1,
    paddingBottom: 80,
  },
  description: {
    textAlign: "center",
    fontFamily: "ojuRegular",
    fontSize: 20,
  },
});
