import React from "react";
import { View, Text, Image, StyleSheet } from "react-native";

type DestinationItemProps = {
  name: string;
  imageUrl: string;
  costVisit: string;
  foundedYear: number;
  rating: number;
  description: string;
  listindex: number;
};

function DestinationItem({
  name,
  imageUrl,
  costVisit,
  foundedYear,
  rating,
  description,
  listindex,
}: DestinationItemProps) {
  return (
    <View style={styles.destinationItem}>
      <Image source={{ uri: imageUrl }} style={styles.image} />
      <View style={styles.details}>
        <Text style={styles.title}>{name}</Text>
        <Text>Founded: {foundedYear}</Text>
        <Text>Cost to Visit: ${costVisit}</Text>
        <Text>Rating: {rating}</Text>
        <Text numberOfLines={2}>{description}</Text>
      </View>
    </View>
  );
}

export default DestinationItem;

const styles = StyleSheet.create({
  destinationItem: {
    marginVertical: 12,
    backgroundColor: "#fff",
    borderRadius: 10,
    overflow: "hidden",
    elevation: 3,
    marginHorizontal: 16,
  },
  image: {
    width: "100%",
    height: 200,
  },
  details: {
    padding: 10,
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 4,
  },
});
