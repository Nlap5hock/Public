import Country from "../models/countries";
import Destination from "../models/destinations";


export const COUNTRIES: Country[] = [
  new Country("c1", "Spain", "#f3b84b"),
  new Country("c2", "Italy", "#ec7a5b"),
  new Country("c3", "Norway", "#57a4e9"),
  new Country("c4", "Denmark", "#4421bd"),
  new Country("c5", "England", "#2150bd"),
  new Country("c6", "Portugal", "#a5bd21"),
  new Country("c7", "Brazil", "#70d529"),
  new Country("c8", "Costa Rica", "#29b6d5"),
  new Country("c9", "Mexico", "#d52c29"),
  new Country("c10", "Switzerland", "#6ec2f5"),

];

export const DESTINATIONS: Destination[] = [
  new Destination(
    "d1",
    "c1",
    "Barcelona",
    "150",
    -100,
    4.7,
    "A major cultural, economic, and financial centre in southwestern Europe, as well as the main biotech hub in Spain.",
    "https://d3dqioy2sca31t.cloudfront.net/Projects/cms/production/000/020/484/original/d0531471711b367b94abfd4dbc29e6ae/spain-barcelona-sagrada-familia-080416-az.jpg"
  ),
  new Destination(
    "d2",
    "c2",
    "Venice",
    "421",
    80,
    5.0,
    "Built on more than 100 small islands in a lagoon in the Adriatic Sea. It has no roads, just canals.",
    "https://lp-cms-production.imgix.net/2021-06/GettyRF_543346423.jpg"
  ),
  new Destination(
    "d3",
    "c3",
    "Oslo",
    "100",
    1049,
    4.9,
    "The economic and governmental centre of Norway.",
    "https://www.lot.com/content/dam/lot/lot-com/destination-photos/norwegia/GettyImages-880090210_osl.jpg"
  ),
  new Destination(
    "d4",
    "c4",
    "Christiansborg Palace",
    "100",
    1745,
    4.9,
    "It was built by King Christian VI as a new main residence in Copenhagen, Denmark, on the site of the former Copenhagen Castle.",
    "https://kenzly.com/wp-content/uploads/2025/01/Christiansborg-Palace.jpg"
  ),
  new Destination(
    "d5",
    "c5",
    "Big Ben",
    "150",
    1859,
    4.7,
    "Big Ben is the nickname for the Great Bell of the Great Clock of Westminster, and, by extension, for the clock tower itself.",
    "https://5857532.fs1.hubspotusercontent-na1.net/hubfs/5857532/00%20Head%20Office%20and%20Corporate/00%20Brand%2C%20Website%20and%20Social%20Media%20Collateral/06%20Website%20and%20Digital%20Asets/Westminster/Outings%20and%20Excursions/Houses%20of%20Parliament-1-1.png"
  ),
  new Destination(
    "d6",
    "c6",
    "Lisbon",
    "1400",
    -1200,
    4.2,
    "The capital and largest city, followed by Porto, which is the only other metropolitan area..",
    "https://t3.gstatic.com/licensed-image?q=tbn:ANd9GcQVKU3mcP_-VpJ00_F6eMxr1qVo4GTa2U6IHUAyLx2oXcJzLpZ1S464CWwLQwW9Uy9YOgxQ4xnwOwansSXE"
  ),
  new Destination(
    "d7",
    "c7",
    "Rio de Janeiro",
    "100",
    1565,
    4.9,
    "A huge seaside city in Brazil, famed for its Copacabana and Ipanema beaches and 38m Christ the Redeemer statue",
    "https://media.tacdn.com/media/attractions-splice-spp-674x446/0e/3b/66/8f.jpg"
  ),
  new Destination(
    "d8",
    "c8",
    "San José",
    "150",
    1777,
    4.9,
    "A large city surrounded by rolling hills in Silicon Valley, a major technology hub in California's Bay Area..",
    "https://cdn.britannica.com/62/194162-050-C4D6DD9A/National-Theatre-San-Jose-Costa-Rica.jpg?w=400&h=225&c=crop"
  ),
  new Destination(
    "d9",
    "c9",
    "Mexico City",
    "120",
    1970,
    4.8,
    "A Mexican city on the Yucatán Peninsula bordering the Caribbean Sea, is known for its beaches, numerous resorts and nightlife.",
    "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d8/Cancun_Strand_Luftbild_%2822143397586%29.jpg/1200px-Cancun_Strand_Luftbild_%2822143397586%29.jpg"
  ),
  new Destination(
    "d10",
    "c10",
    "Rhine Falls",
    "100",
    -15000,
    4.9,
    "A waterfall on the High Rhine in Switzerland. It is the most powerful waterfall in Europe and a popular tourist attraction.",
    "https://upload.wikimedia.org/wikipedia/commons/2/26/SBB_RABe_514_DTZ_Rheinfall.jpg"
  ),
];
