//Set the color to use on the code
const Colors = {
  accent1: "#c0f0c7",
  accent2: "#42342b",
  primary1: "#ffffff",
  primary2: "#2ba53c",
  primary3: "#0e5619",
};

export default Colors;
