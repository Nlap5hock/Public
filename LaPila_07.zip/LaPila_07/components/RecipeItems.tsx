import { View, StyleSheet, Text, TouchableOpacity } from "react-native"; 
import Colors from "../constants/colors"; 
import React from "react";

interface RecipeItemsProps {
  title: string;
  onView: () => void;
  onDelete: () => void;
}

const RecipeItems: React.FC<RecipeItemsProps> = (props) => {
  return (
    <View style={styles.item}>
      <View style={styles.itemTitleContainer}>
        <Text style={styles.itemTitle}>{props.title}</Text>
      </View>
      <View style={styles.itemButtonsContainer}>
        <TouchableOpacity
          style={[styles.button, { backgroundColor: Colors.primary1 }]}
          onPress={props.onView}
        >
          <Text style={styles.buttonText}>View</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.button, { backgroundColor: Colors.primary1 }]}
          onPress={props.onDelete}
        >
          <Text style={styles.buttonText}>Delete</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

export default RecipeItems;

const styles = StyleSheet.create({
  item: {
    flexDirection: "row",
    justifyContent: "space-between",
    margin: 8,
    borderRadius: 6,
    backgroundColor: Colors.accent1,
  },
  itemTitleContainer: {
    justifyContent: "center",
  },
  itemTitle: {
    fontFamily: "paperNoteSketch",
    fontSize: 20,
    color: Colors.primary1,
    padding: 8,
  },
  itemButtonsContainer: {
    flexDirection: "row",
  },
  button: {
    marginVertical: 5,
    marginHorizontal: 3,
    borderRadius: 5,
    padding: 8,
    alignItems: "center",
    justifyContent: "center",
  },
  buttonText: {
    color: Colors.primary3,
    textAlign: "center",
  },
});