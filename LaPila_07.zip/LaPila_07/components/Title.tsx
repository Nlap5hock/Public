import { Text, StyleSheet } from "react-native"; 
import Colors from "../constants/colors"; 
import React from "react";

interface TitleProps { 
  children: React.ReactNode; 
} 

const Title: React.FC<TitleProps> = (props) => { 
  return <Text style={styles.title}>{props.children}</Text>; 
}; 

export default Title; 

const styles = StyleSheet.create({ 
  title: { 
    fontSize: 55, 
    color: Colors.primary1, 
    textShadowColor: Colors.accent1, 
    textShadowRadius: 25, 
    fontFamily: "noteFont", 
    textAlign: "center", 
  }, 
});