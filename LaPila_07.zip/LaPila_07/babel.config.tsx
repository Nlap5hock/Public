import { Api } from 'some-module'; 

const config = (api: Api): { presets: string[] } => {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
  };
};

export default config;