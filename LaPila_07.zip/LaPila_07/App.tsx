
import { useState } from "react";
import { StyleSheet, View } from "react-native";
import HomeScreen from "./screens/HomeScreen";
import AddNewRecipeScreen from "./screens/AddNewRecipeScreen";
import RecipesScreen from "./screens/Recipe";
import Colors from "./constants/colors";
import React from "react";
{

  const [currentScreen, setCurrentScreen]: [string, (screen: string) => void] = useState("home");
  const [currentID, setCurrentID]: [number, (id: number) => void] = useState(3);
  
  const [currentRecipes, setCurrentRecipes]: [Array<{ id: number; title: string; text: string }>, (recipes: Array<{ id: number; title: string; text: string }>) => void] = useState([
    {
      id: 1,
      title: "Chocolate Chip Cookies",
      text:
        "Ingredients:\n1 cup (2 sticks) unsalted butter, softened\n3/4 cup granulated sugar\n3/4 cup packed brown sugar\n1 tsp vanilla extract\n 2 large eggs" +
        "\n2 1/4 cups all-purpose flour\n1 tsp baking soda\n1/2 tsp salt\n2 cups chocolate chips" 
        +
        "Preheat your oven to 350°F (175°C) and line baking sheets with parchment paper." +
        "In a large bowl, cream together the butter, granulated sugar, and brown sugar until smooth." +
        "Beat in the vanilla extract and eggs, one at a time." +
        "In another bowl, mix together the flour, baking soda, and salt" +
        "Gradually add the dry ingredients to the wet mixture, mixing until just combined." +
        "Stir in the chocolate chips." +
        "Drop rounded tablespoons of dough onto the baking sheets, spacing them about 2 inches apart." +
        "Bake for 10-12 minutes or until the edges are golden brown." +
        "Let them cool on the baking sheet for a few minutes before transferring to a wire rack."
    },
    {
      id: 2,
      title: "Chicken Cutlets",
      text:
        "Ingredients:\n4 boneless, skinless chicken breasts\n1 cup all-purpose flour\n2 large eggs, beaten\n1 1/2 cups breadcrumbs (preferably panko)\n1/2 cup grated Parmesan cheese (optional)\n" +
        "Salt and pepper, to taste\nOlive oil for frying\n\n"
         +
        "Flatten the chicken breasts to an even thickness using a mallet or rolling pin." +
        "Set up a breading station: one plate with flour, one with beaten eggs, and one with breadcrumbs mixed with Parmesan (if using), salt, and pepper." +
        "Dredge each chicken breast in flour, dip into the egg, and then coat with breadcrumbs." +
        "Heat olive oil in a large skillet over medium-high heat." +
        "rCook the chicken cutlets for about 4-5 minutes per side, until golden brown and cooked through (internal temperature should reach 165°F or 75°C)." +
        "Transfer to paper towels to drain excess oil.",
    },
  ]);

  function homeScreenHandler(): void {
    setCurrentScreen("home");
  }

  function recipesScreenHandler(): void {
    setCurrentScreen("recipes");
  }

  function AddNewRecipeScreenHandler(): void {
    setCurrentScreen("add");
  }

  function addRecipeHandler(inputRrecipeName: string, inputRecipeText: string): void {
    setCurrentRecipes((currentRecipes) => [
      ...currentRecipes,
      { id: currentID, title: inputRrecipeName, text: inputRecipeText },
    ]);
    
    setCurrentID(currentID + 1);
    
    recipesScreenHandler();
  }

  function deleteRecipeHandler(id: number): void {
    setCurrentRecipes((currentRecipes) => 
      currentRecipes.filter((item) => item.id !== id)
    );
  }
  
  let screen: TSX.Element = <HomeScreen onNext={recipesScreenHandler} />;

  if (currentScreen === "add") {
    screen = (
      <AddNewRecipeScreen
        onAdd={addRecipeHandler}
        onCancel={recipesScreenHandler}
      />
    );
  }
  
  if (currentScreen === "recipes") {
    screen = (
      <RecipesScreen
        onHome={homeScreenHandler}
        onAdd={AddNewRecipeScreenHandler}
        onDelete={deleteRecipeHandler}
        currentRecipes={currentRecipes}
      />
    );
  }

  return ( 
    <>
      <StatusBar style="auto" />
      <SafeAreaProvider style={styles.container}>{screen}</SafeAreaProvider>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.primary3,
    alignItems: "center",
    justifyContent: "center",
  },
});

