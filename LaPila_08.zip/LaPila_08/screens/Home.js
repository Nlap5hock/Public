import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Switch,
  ImageBackground,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { RadioGroup } from "react-native-radio-buttons-group";
import BouncyCheckbox from "react-native-bouncy-checkbox";
import NavButton from "../component/NavButton";
import Title from "../component/Title";
import Colors from "../constants/colors";

export default HomeScreen;
const styles = StyleSheet.create({
  rootContainer: {
    flex: 1,
  },
  titleContainer: {
    marginBottom: 10,
    borderWidht: 2,
    borderRadius: 5,
    borderColor: Colors.primary2,
    paddingHorizontal: 30,
    paddingVertical: 5,
    paddingBottom: 10,
  },
  scrollContainer: {
    flex: 1,
  },
  radioContainer: {
    justifyContent: "space-around",
    alignItems: "center",
  },
  radioHeader: {
    fontFamily: "Arial",
    color: Colors.primary2,
    fontSize: 25,
  },
  radioGroupLabel: {
    fontFamily: "Arial",
    fontSize: 15,
    color: Colors.accent1,
    justifyContent: "center",
    paddingTop: 20,
  },

  radioGroup: {
    paddingBottom: 30,
  },
 
  rowContainer: {
    flexDirection: "row",
    justifyContent: "space-evenly",
    paddingBottom: 20,
  },
  checkBoxContainer: {},
  checkBoxHeader: {
    fontSize: 25,
    fontFamily: "Arial",
    color: Colors.primary2,
    paddingBottom: 20,
  },
  checkBoxSubContainer: {
    padding: 2,
  },
  signUpContainer: {
    justifyContent: "space-between",
  },

  signUpLabel: {
    fontFamily: "Arial",
    fontSize: 15,
    color: Colors.accent1,
    justifyContent: "center",
    paddingTop: 20,
  },

  signUpSubContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
 
  buttonContainer: {
    alignItems: "center",
  },
});

function HomeScreen(props) {
  const insets = useSafeAreaInsets();
  return (
    <ImageBackground
      source={require("../assets/images/background.jpg")}
      resizeMode="stretch"
      style={styles.rootContainer}
      imageStyle={styles.backgroundImage}
    >
      <View
        style={[
          styles.rootContainer,
          {
            paddingTop: insets.top,
            paddingBottom: insets.bottom,
            paddingLeft: insets.left,
            paddingRight: insets.right,
          },
        ]}
      >
        <View style={styles.titleContainer}>
          <Title> Bike Repair Shop </Title>
        </View>

        <ScrollView style={styles.scrollContainer}>
          <View style={styles.radioContainer}>
            <Text style={styles.radioHeader}>Service Times:</Text>
            <RadioGroup
              radioButtons={props.repairTimeRadioButtons}
              onPress={props.onSetRepairTimeId}
              selectedId={props.repairTimeId}
              layout="row"
              containerStyle={styles.radioGroup}
              labelStyle={styles.radioGroupLabel}
            />
          </View>

          <View style={styles.rowContainer}>
            <View style={styles.checkBoxContainer}>
              <Text style={styles.checkBoxHeader}>Service Options:</Text>
              <View style={styles.checkBoxSubContainer}>
                {props.services.map((item) => {
                  return (
                    <BouncyCheckbox
                      key={item.id}
                      text={item.name}
                      onPress={props.onSetServices.bind(this, item.id)}
                      textStyle={{
                        textDecorationLine: "none",
                        color: Colors.accent1,
                        fontFamily: "Arial",
                      }}
                      innerIconStyle={{
                        borderRadius: 0,
                        borderColor: Colors.primary2,
                      }}
                      iconStyle={{
                        borderRadius: 0,
                      }}
                      fillColor={Colors.primary2}
                      style={{
                        padding: 2,
                      }}
                    />
                  );
                })}
              </View>
            </View>
          </View>

          <View style={styles.rowContainer}>
            <View style={styles.signUpContainer}>
              <View style={styles.signUpSubContainer}>
                <Text style={styles.signUpLabel}>Sign up for our newsletter</Text>
                <Switch
                  onValueChange={props.onSetNewsletter}
                  value={props.newsletter}
                  thumbColor={
                    props.newsletter ? Colors.primary2 : Colors.primary3
                  }
                  trackColor={{
                    false: Colors.primary1,
                    true: Colors.primary3,
                  }}
                />
              </View>

              <View style={styles.signUpSubContainer}>
                <Text style={styles.signUpLabel}>Membership Rental</Text>
                <Switch
                  onValueChange={props.onSetMembershipRental}
                  value={props.membershipRental}
                  thumbColor={
                    props.membershipRental
                      ? Colors.primary2
                      : Colors.primary3
                  }
                  trackColor={{
                    false: Colors.primary1,
                    true: Colors.primary3,
                  }}
                />
              </View>
            </View>
          </View>
          <View style={styles.buttonContainer}>
            <NavButton onPress={props.onNext}>Submit</NavButton>
          </View>
        </ScrollView>
      </View>
    </ImageBackground>
  );
}


