const Colors = {
  accent1: "#627373",  
  accent2: "#42ade3",
  primary1: "#1c58c9",
  primary2: "#000000",
  primary3: "#FFFFFF",
};
export default Colors;
